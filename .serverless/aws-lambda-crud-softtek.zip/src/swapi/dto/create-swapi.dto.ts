export class CreateSwapiDto {}
